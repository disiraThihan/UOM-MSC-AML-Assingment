// Colombo Suburban Land Valuation System - Client Logic

function switchTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));

    const targetTab = document.getElementById(`tab-${tabId}`);
    const targetBtn = document.getElementById(`tab-${tabId}-btn`);
    if (targetTab) targetTab.classList.add('active');
    if (targetBtn) targetBtn.classList.add('active');
}

async function calculateValuation() {
    const form = document.getElementById('valuation-form');
    const formData = new FormData(form);

    const payload = {
        locality: formData.get('locality'),
        perch_size: parseFloat(formData.get('perch_size')),
        dist_expressway_interchange_km: parseFloat(formData.get('dist_expressway_interchange_km')),
        dist_nearest_university_km: parseFloat(formData.get('dist_nearest_university_km')),
        dist_main_bus_route_m: parseInt(formData.get('dist_main_bus_route_m')),
        road_width_ft: parseInt(formData.get('road_width_ft')),
        road_type: formData.get('road_type'),
        zoning_type: formData.get('zoning_type'),
        deed_type: formData.get('deed_type'),
        topography: formData.get('topography'),
        flood_risk_level: formData.get('flood_risk_level'),
        shape_regularity: formData.get('shape_regularity'),
        pipe_water_available: document.getElementById('pipe_water_available').checked ? 1 : 0,
        three_phase_electricity: document.getElementById('three_phase_electricity').checked ? 1 : 0
    };

    const calcBtn = document.getElementById('btn-calculate');
    const originalText = calcBtn.innerHTML;
    calcBtn.innerHTML = 'Calculating Ensemble Valuation...';
    calcBtn.disabled = true;

    try {
        const response = await fetch('/api/predict', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!response.ok) throw new Error("Valuation calculation failed");
        const data = await response.json();

        // Update UI Results
        document.getElementById('res-perch-price').innerText = data.price_per_perch_lakhs.toFixed(2);
        document.getElementById('res-perch-rupees').innerText = (data.price_per_perch_lakhs * 100000).toLocaleString('en-US', { maximumFractionDigits: 0 });
        document.getElementById('res-total-millions').innerText = data.total_price_millions.toFixed(2);
        document.getElementById('res-extent-summary').innerText = payload.perch_size.toFixed(1);
        document.getElementById('res-model-name').innerText = data.model_used;
        document.getElementById('res-base-value').innerText = data.base_expected_value.toFixed(2);

        // Render Local SHAP Breakdown
        renderShapBreakdown(data.shap_attributions);

    } catch (err) {
        console.error("Valuation Error:", err);
        alert("Could not calculate valuation. Please ensure backend server is running.");
    } finally {
        calcBtn.innerHTML = originalText;
        calcBtn.disabled = false;
    }
}

function renderShapBreakdown(attributions) {
    const list = document.getElementById('shap-breakdown-list');
    list.innerHTML = '';

    if (!attributions || attributions.length === 0) {
        list.innerHTML = '<p class="section-desc">No SHAP breakdown available.</p>';
        return;
    }

    // Find max abs contribution for relative bar width
    const maxVal = Math.max(...attributions.map(a => Math.abs(a.impact_lakhs)), 0.01);

    attributions.forEach(item => {
        const isPos = item.impact_lakhs >= 0;
        const widthPct = Math.min(100, Math.max(8, (Math.abs(item.impact_lakhs) / maxVal) * 100));

        const div = document.createElement('div');
        div.className = `shap-item ${isPos ? 'positive' : 'negative'}`;
        div.innerHTML = `
            <div class="shap-info">
                <span class="shap-feat">${item.feature_name}</span>
                <span class="shap-contrib">${isPos ? '+' : ''}${item.impact_lakhs.toFixed(2)} Lakhs</span>
            </div>
            <div class="shap-bar-bg">
                <div class="shap-bar-fill ${isPos ? 'pos' : 'neg'}" style="width: ${widthPct}%"></div>
            </div>
        `;
        list.appendChild(div);
    });
}

async function loadBenchmarks() {
    const tbody = document.getElementById('benchmark-rows');
    try {
        const response = await fetch('/api/benchmark');
        if (!response.ok) return;
        const results = await response.json();

        tbody.innerHTML = '';
        results.forEach(m => {
            let tierClass = 'tier-baseline';
            let tierLabel = 'Baseline';

            if (m.test_r2 >= 0.98) {
                tierClass = 'tier-s';
                tierLabel = 'Tier S (State-of-Art)';
            } else if (m.test_r2 >= 0.95) {
                tierClass = 'tier-a';
                tierLabel = 'Tier A (Advanced)';
            } else if (m.test_r2 >= 0.90) {
                tierClass = 'tier-b';
                tierLabel = 'Tier B';
            }

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><span class="badge-tag ${m.category === 'Advanced Ensemble' ? 'live-badge' : 'corridor-badge'}">${m.category}</span></td>
                <td><strong>${m.model_name}</strong></td>
                <td>${m.cv_r2_mean.toFixed(4)} ± ${m.cv_r2_std.toFixed(4)}</td>
                <td><strong style="color: #60a5fa">${m.test_r2.toFixed(4)}</strong></td>
                <td>${m.test_rmse.toFixed(3)}</td>
                <td>${m.test_mae.toFixed(3)}</td>
                <td>${m.test_mape.toFixed(2)}%</td>
                <td><span class="tier-badge ${tierClass}">${tierLabel}</span></td>
            `;
            tbody.appendChild(tr);
        });
    } catch (err) {
        console.warn("Could not load dynamic benchmarks table:", err);
    }
}

// Initial execute on page load
document.addEventListener('DOMContentLoaded', () => {
    loadBenchmarks();
    calculateValuation();
});
